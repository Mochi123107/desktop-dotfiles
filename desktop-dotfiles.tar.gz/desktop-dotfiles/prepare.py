from pathlib import Path
root = Path(__file__).resolve().parent
for path in list((root / '.config').rglob('*')) + list((root / '.local').rglob('*')):
    if not path.is_file():
        continue
    try:
        text = path.read_text()
    except UnicodeDecodeError:
        continue
    if '/home/USER' in text:
        path.write_text(text.replace('/home/USER', str(Path.home())))
print('分享副本路径已适配，未安装或修改当前桌面配置。')
