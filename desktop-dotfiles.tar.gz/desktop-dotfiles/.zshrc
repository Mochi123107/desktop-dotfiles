source /usr/share/cachyos-zsh-config/cachyos-config.zsh

# Transparent terminal: readable suggestions and syntax colors.
ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE='fg=#A6B4CE'
ZSH_HIGHLIGHT_STYLES[comment]='fg=#A6B4CE'
ZSH_HIGHLIGHT_STYLES[command]='fg=#B2EBCF'
ZSH_HIGHLIGHT_STYLES[builtin]='fg=#B2EBCF'
ZSH_HIGHLIGHT_STYLES[alias]='fg=#B2EBCF'
ZSH_HIGHLIGHT_STYLES[unknown-token]='fg=#FFA6BB,bold'
ZSH_HIGHLIGHT_STYLES[path]='fg=#B5D7FF,underline'
