#!/usr/bin/python3
"""Mako notification archive, Waybar indicator and a GTK message center."""
import argparse
import contextlib
import fcntl
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import shlex
import signal
import sqlite3
import subprocess
import sys
import time
from datetime import datetime

os.umask(0o077)
ROOT = Path(os.environ.get('XDG_STATE_HOME', str(Path.home()/'.local/state'))) / 'notification-center'
DB = ROOT / 'history.sqlite3'
SELF = str(Path(__file__).resolve())

class PlainText(HTMLParser):
    def __init__(self, value):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.feed(value or '')
    def handle_data(self, value):
        self.parts.append(value)
    def handle_starttag(self, tag, attrs):
        if tag in ('br', 'p', 'div'): self.parts.append('\n')
    def handle_endtag(self, tag):
        if tag in ('p', 'div'): self.parts.append('\n')

def plain(value):
    return ''.join(PlainText(str(value or '')).parts).strip()

def command(*args):
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=3)
        return result.stdout.strip() if result.returncode == 0 else ''
    except (OSError, subprocess.TimeoutExpired):
        return ''

@contextlib.contextmanager
def database():
    ROOT.mkdir(mode=0o700, parents=True, exist_ok=True)
    conn = sqlite3.connect(DB, timeout=8)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute("""CREATE TABLE IF NOT EXISTS messages (
            source TEXT PRIMARY KEY, app TEXT, icon TEXT, summary TEXT, body TEXT,
            urgency TEXT, received REAL, fingerprint TEXT, unread INTEGER DEFAULT 1,
            deleted INTEGER DEFAULT 0, imported INTEGER DEFAULT 0)""")
        conn.execute('CREATE INDEX IF NOT EXISTS messages_order ON messages(deleted, received DESC)')
        yield conn
        conn.commit()
    finally:
        conn.close()

def daemon_token():
    owner = command('busctl', '--user', 'call', 'org.freedesktop.DBus',
                    '/org/freedesktop/DBus', 'org.freedesktop.DBus',
                    'GetNameOwner', 's', 'org.freedesktop.Notifications')
    if not owner: return None
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    return boot + ':' + shlex.split(owner)[-1]

def archive(items, token, imported=False):
    now = time.time()
    with database() as db:
        for index, item in enumerate(sorted(items, key=lambda row: int(row['id']))):
            source = token + ':' + str(item['id'])
            values = [str(item.get('app_name') or '应用'), str(item.get('app_icon') or ''),
                      plain(item.get('summary'))[:4096], plain(item.get('body'))[:65536],
                      str(item.get('urgency') or 'normal')]
            fingerprint = hashlib.sha256(json.dumps(values, ensure_ascii=False).encode()).hexdigest()
            old = db.execute('SELECT fingerprint FROM messages WHERE source=?', (source,)).fetchone()
            if old and old['fingerprint'] == fingerprint: continue
            # Keep tombstones so a cleared message cannot be re-imported.
            db.execute("""INSERT INTO messages
                (source,app,icon,summary,body,urgency,received,fingerprint,imported)
                VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(source) DO UPDATE SET
                app=excluded.app,icon=excluded.icon,summary=excluded.summary,body=excluded.body,
                urgency=excluded.urgency,received=excluded.received,fingerprint=excluded.fingerprint,
                unread=1,imported=excluded.imported WHERE messages.deleted=0""",
                (source, *values, now + index / 1000000, fingerprint, int(imported)))

def capture(notification_id=None, imported=False):
    token = daemon_token()
    if token is None: return
    for attempt in range(5 if notification_id else 1):
        items = {}
        for action in ('history', 'list'):
            try:
                data = json.loads(command('makoctl', action, '-j') or '[]')
                for item in data:
                    if notification_id is None or str(item['id']) == str(notification_id):
                        items[item['id']] = item
            except (ValueError, KeyError, TypeError):
                continue
        if items:
            archive(list(items.values()), token, imported)
            return
        if notification_id: time.sleep(0.06)

def dnd():
    return 'do-not-disturb' in command('makoctl', 'mode').splitlines()

def toggle_dnd():
    command('makoctl', 'mode', '-t', 'do-not-disturb')

def watch():
    capture(imported=True)
    last = None
    while True:
        with database() as db:
            total, unread = db.execute('SELECT count(*), coalesce(sum(unread),0) FROM messages WHERE deleted=0').fetchone()
        quiet = dnd()
        icon = '' if quiet else ''
        text = icon
        result = {'text': text, 'class': 'dnd' if quiet else 'unread' if unread else 'empty',
                  'tooltip': f'消息中心 · {unread} 条未读 / {total} 条消息\n左键查看 · 右键勿扰 · Super + N\n' + ('勿扰已开启' if quiet else '弹窗 5 秒后自动收起，历史保留')}
        line = json.dumps(result, ensure_ascii=False)
        if line != last:
            print(line, flush=True)
            last = line
        time.sleep(2)

def show_center():
    import gi
    gi.require_version('Gtk', '3.0')
    gi.require_version('GtkLayerShell', '0.1')
    gi.require_version('GLibUnix', '2.0')
    from gi.repository import Gtk, Gdk, GLib, GLibUnix, GtkLayerShell, Pango
    runtime = Path(os.environ.get('XDG_RUNTIME_DIR', '/tmp'))
    lock = open(runtime / f'notification-center-{os.getuid()}.lock', 'a+')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        lock.seek(0)
        try: os.kill(int(lock.read()), signal.SIGUSR1)
        except (ValueError, ProcessLookupError): pass
        return
    lock.seek(0); lock.truncate(); lock.write(str(os.getpid())); lock.flush()
    capture(imported=True)
    window = Gtk.Window(title='消息中心')
    window.set_name('notification-center')
    window.set_app_paintable(True)
    visual = window.get_screen().get_rgba_visual()
    if visual: window.set_visual(visual)
    window.set_default_size(472, 700)
    window.set_resizable(False)
    GtkLayerShell.init_for_window(window)
    GtkLayerShell.set_namespace(window, 'notification-center')
    GtkLayerShell.set_layer(window, GtkLayerShell.Layer.OVERLAY)
    GtkLayerShell.set_keyboard_mode(window, GtkLayerShell.KeyboardMode.ON_DEMAND)
    for edge in (GtkLayerShell.Edge.TOP, GtkLayerShell.Edge.RIGHT):
        GtkLayerShell.set_anchor(window, edge, True)
    GtkLayerShell.set_margin(window, GtkLayerShell.Edge.TOP, 12)
    GtkLayerShell.set_margin(window, GtkLayerShell.Edge.RIGHT, 12)
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
    outer.set_name('message-panel')
    window.add(outer)
    def label(text, name=None):
        widget = Gtk.Label(label=text, xalign=0)
        if name: widget.set_name(name)
        return widget
    def button(text, tooltip, callback):
        widget = Gtk.Button(label=text)
        widget.set_tooltip_text(tooltip)
        widget.connect('clicked', callback)
        return widget
    header = Gtk.Box(spacing=12)
    header.pack_start(label('  消息中心', 'heading'), True, True, 0)
    close = button('×', '关闭 · Escape', lambda _: Gtk.main_quit())
    close.set_name('close-button')
    header.pack_end(close, False, False, 0)
    outer.pack_start(header, False, False, 0)
    tools = Gtk.Box(spacing=8)
    count = label('', 'muted')
    tools.pack_start(count, True, True, 0)
    quiet = button('', '开启后静默接收消息，历史仍会保存', lambda _: (toggle_dnd(), refresh(True)))
    tools.pack_end(quiet, False, False, 0)
    def clear(_):
        with database() as db: db.execute('UPDATE messages SET deleted=1, unread=0, app="", icon="", summary="", body=""')
        command('makoctl', 'dismiss', '-a')
        refresh(True)
    tools.pack_end(button('清空', '清空所有消息记录', clear), False, False, 0)
    outer.pack_start(tools, False, False, 0)
    search = Gtk.SearchEntry(placeholder_text='搜索应用、标题或消息内容…')
    outer.pack_start(search, False, False, 0)
    scroll = Gtk.ScrolledWindow()
    scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    scroll.set_min_content_height(460)
    outer.pack_start(scroll, True, True, 0)
    messages = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    scroll.add(messages)
    footer = label('弹窗自动收起 · 历史保存在本机', 'footer')
    outer.pack_start(footer, False, False, 0)
    snapshot = [None]
    limit = [60]
    def remove(_, source):
        with database() as db: db.execute('UPDATE messages SET deleted=1, unread=0, app="", icon="", summary="", body="" WHERE source=?', (source,))
        refresh(True)
    def more(_):
        limit[0] += 60
        refresh(True)
    def refresh(force=False):
        is_quiet = dnd()
        query = search.get_text().strip().casefold()
        with database() as db:
            total, latest = db.execute('SELECT count(*), max(received) FROM messages WHERE deleted=0').fetchone()
            db.execute('UPDATE messages SET unread=0 WHERE deleted=0 AND unread=1')
            state = (total, latest, query, is_quiet, limit[0])
            if not force and snapshot[0] == state: return True
            rows = db.execute('SELECT * FROM messages WHERE deleted=0 ORDER BY received DESC').fetchall()
        snapshot[0] = state
        count.set_text(f'{len(rows)} 条消息')
        quiet.set_label('  勿扰开启' if is_quiet else '  勿扰关闭')
        quiet.get_style_context().remove_class('enabled')
        if is_quiet: quiet.get_style_context().add_class('enabled')
        adjustment = scroll.get_vadjustment()
        position = adjustment.get_value()
        for child in messages.get_children(): child.destroy()
        visible = [r for r in rows if query in (r['app']+' '+r['summary']+' '+r['body']).casefold()]
        if not visible:
            empty = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
            empty.set_name('empty-state')
            empty.pack_start(label('󰂛', 'empty-icon'), False, False, 0)
            empty.pack_start(label('没有匹配的消息' if query else '消息都在这里'), False, False, 0)
            empty.pack_start(label('新消息到达后会自动保存', 'muted'), False, False, 0)
            messages.pack_start(empty, False, False, 0)
        for row in visible[:limit[0]]:
            card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
            card.set_name('message-card')
            if row['urgency'] == 'critical': card.get_style_context().add_class('critical')
            top = Gtk.Box(spacing=8)
            app = label(row['app'], 'app-name')
            app.set_ellipsize(Pango.EllipsizeMode.END)
            top.pack_start(app, True, True, 0)
            when = '导入记录' if row['imported'] else datetime.fromtimestamp(row['received']).strftime('%m-%d %H:%M')
            top.pack_end(button('×', '删除这条消息', lambda widget, key=row['source']: remove(widget, key)), False, False, 0)
            top.pack_end(label(when, 'timestamp'), False, False, 0)
            card.pack_start(top, False, False, 0)
            if row['summary']:
                title = label(row['summary'], 'message-title')
                title.set_line_wrap(True); title.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
                title.set_max_width_chars(38); title.set_selectable(True)
                card.pack_start(title, False, False, 0)
            if row['body']:
                body = label(row['body'], 'message-body')
                body.set_line_wrap(True); body.set_line_wrap_mode(Pango.WrapMode.WORD_CHAR)
                body.set_max_width_chars(42); body.set_selectable(True)
                card.pack_start(body, False, False, 0)
            messages.pack_start(card, False, False, 0)
        if len(visible) > limit[0]:
            messages.pack_start(button(f'加载更多 · 还有 {len(visible)-limit[0]} 条', '查看更早消息', more), False, False, 0)
        messages.show_all()
        GLib.idle_add(lambda: (adjustment.set_value(position), False)[1])
        return True
    search.connect('search-changed', lambda _: refresh(True))
    window.connect('key-press-event', lambda _, event: (Gtk.main_quit(), True)[1] if event.keyval == Gdk.KEY_Escape else False)
    window.connect('destroy', Gtk.main_quit)
    GLibUnix.signal_add(GLib.PRIORITY_DEFAULT, signal.SIGUSR1, lambda: (Gtk.main_quit(), False)[1])
    provider = Gtk.CssProvider()
    provider.load_from_path(str(Path(SELF).with_name('style.css')))
    Gtk.StyleContext.add_provider_for_screen(window.get_screen(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    refresh(True)
    window.show_all()
    window.present()
    search.grab_focus()
    GLib.timeout_add_seconds(2, refresh)
    Gtk.main()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--capture', nargs='?', const='all')
    parser.add_argument('--watch', action='store_true')
    parser.add_argument('--dnd', action='store_true')
    args = parser.parse_args()
    if args.capture: capture(None if args.capture == 'all' else args.capture)
    elif args.watch: watch()
    elif args.dnd: toggle_dnd()
    else: show_center()
