#!/usr/bin/python3
"""A transparent, click-through desktop clock for the primary monitor."""
import fcntl
import html
import re
from datetime import datetime
from pathlib import Path

import cairo
import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
gi.require_version('GtkLayerShell', '0.1')
from gi.repository import Gdk, GLib, Gtk, GtkLayerShell

# Keep autostart and manual launches from creating overlapping clocks.
lock_dir = Path.home() / '.local/state/desktop-clock'
lock_dir.mkdir(parents=True, exist_ok=True)
lock_path = lock_dir / 'clock.lock'
lock = lock_path.open('w')
try:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    raise SystemExit(0)

window = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
window.set_title('Desktop Clock')
window.set_app_paintable(True)
window.set_decorated(False)
window.set_accept_focus(False)
visual = window.get_screen().get_rgba_visual()
if visual:
    window.set_visual(visual)
GtkLayerShell.init_for_window(window)
GtkLayerShell.set_namespace(window, 'desktop-clock')
GtkLayerShell.set_layer(window, GtkLayerShell.Layer.BOTTOM)
GtkLayerShell.set_keyboard_mode(window, GtkLayerShell.KeyboardMode.NONE)
GtkLayerShell.set_exclusive_zone(window, 0)
GtkLayerShell.set_anchor(window, GtkLayerShell.Edge.LEFT, True)
GtkLayerShell.set_anchor(window, GtkLayerShell.Edge.TOP, True)
display = Gdk.Display.get_default()
monitor = display.get_primary_monitor() or display.get_monitor(0)
if monitor:
    GtkLayerShell.set_monitor(window, monitor)

box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
box.set_name('clock-face')
date_label = Gtk.Label()
date_label.set_name('desktop-date')
date_label.set_xalign(0.0)
time_label = Gtk.Label()
time_label.set_name('desktop-time')
time_label.set_xalign(0.0)
box.pack_start(time_label, False, False, 0)
box.pack_start(date_label, False, False, 0)
logo_label = Gtk.Label()
logo_label.set_name('desktop-logo')
logo_label.set_xalign(0.5)
logo_label.set_markup(Path(__file__).with_name('logo.pango').read_text())
box.pack_start(logo_label, False, False, 0)
logo_tagline = Gtk.Label(label='')
logo_tagline.set_name('desktop-logo-tagline')
logo_tagline.set_xalign(0.5)
logo_tagline.set_markup(Path(__file__).with_name('tagline.pango').read_text())
box.pack_start(logo_tagline, False, False, 0)
window.add(box)
provider = Gtk.CssProvider()
provider.load_from_path(str(Path(__file__).with_name('style.css')))
Gtk.StyleContext.add_provider_for_screen(window.get_screen(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
size_provider = Gtk.CssProvider()
Gtk.StyleContext.add_provider_for_screen(window.get_screen(), size_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)

def position_clock(*_args):
    # GDK geometry uses logical pixels, so this also respects display scaling.
    geometry = monitor.get_geometry() if monitor else window.get_screen().get_monitor_geometry(0)
    # Enlarge the complete composition on larger displays, using logical pixels.
    scale = 1.5 * max(1.15, min(1.8, min(geometry.width / 1707, geometry.height / 960)))
    px = lambda value: round(value * scale, 2)
    # The block logo stores absolute Pango line heights (1024 units per pixel).
    logo_markup = Path(__file__).with_name('logo.pango').read_text()
    logo_label.set_markup(re.sub(
        r'line_height="(\d+)"',
        lambda match: f'line_height="{round(int(match.group(1)) * scale)}"',
        logo_markup,
    ))
    GtkLayerShell.set_margin(window, GtkLayerShell.Edge.LEFT, round(40 * scale))
    GtkLayerShell.set_margin(window, GtkLayerShell.Edge.TOP, max(72, round(52 * scale)))
    size_provider.load_from_data((
        f'#clock-face {{ padding: 0 {px(4)}px {px(6)}px {px(4)}px; }} '
        f'#desktop-time {{ font-size: {px(38)}px; letter-spacing: {px(-1)}px; }} '
        f'#desktop-date {{ font-size: {px(10)}px; letter-spacing: {px(1.5)}px; margin-left: {px(2)}px; }} '
        f'#desktop-logo {{ font-size: {px(13)}px; margin-top: {px(24)}px; margin-left: {px(2)}px; }} '
        f'#desktop-logo-tagline {{ font-size: {px(10)}px; letter-spacing: {px(2)}px; '
        f'margin-top: {px(8)}px; margin-left: {px(2)}px; }}'
    ).encode())

position_clock()
if monitor:
    monitor.connect('notify::geometry', position_clock)

def click_through(widget):
    widget.get_window().input_shape_combine_region(cairo.Region(), 0, 0)

window.connect('realize', click_through)
window.connect('destroy', Gtk.main_quit)

def update():
    now = datetime.now()
    # Explicit English names match the reference regardless of system locale.
    weekdays = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
    months = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December')
    date_label.set_text(f'{weekdays[now.weekday()][:3].upper()}  ·  {now.day:02d} {months[now.month - 1][:3].upper()} {now.year}')
    time_label.set_text(now.strftime('%H:%M'))
    return GLib.SOURCE_CONTINUE

update()
GLib.timeout_add_seconds(1, update)
window.show_all()
Gtk.main()
