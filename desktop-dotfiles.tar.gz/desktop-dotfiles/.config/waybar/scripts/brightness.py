#!/usr/bin/python3
"""Control the external ASUS monitor's hardware brightness over DDC/CI."""
import argparse
import contextlib
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

SELF = str(Path(__file__).resolve())
RUNTIME = Path(os.environ.get('XDG_RUNTIME_DIR', '/tmp'))
MONITOR = ['--model', 'VG27AQ3A']

def ddc(*args):
    result = subprocess.run(['ddcutil', *MONITOR, *map(str,args)],
                            text=True, capture_output=True, timeout=8)
    if result.returncode: raise RuntimeError(result.stderr.strip() or '显示器亮度暂不可用')
    return result.stdout

@contextlib.contextmanager
def locked():
    with open(RUNTIME/f'waybar-brightness-{os.getuid()}.lock','a') as handle:
        fcntl.flock(handle,fcntl.LOCK_EX)
        yield

def read():
    values=ddc('getvcp','10','--terse').split()
    if len(values)!=5 or values[:3]!=['VCP','10','C']:
        raise RuntimeError('显示器未返回有效亮度值')
    current, maximum=map(int,values[3:])
    if maximum<=0: raise RuntimeError('显示器亮度范围无效')
    return current, maximum

def refresh_bar():
    result=subprocess.run(['pgrep','-x','-u',str(os.getuid()),'waybar'],capture_output=True,text=True)
    for pid in result.stdout.split():
        try: os.kill(int(pid),signal.SIGRTMIN+8)
        except ProcessLookupError: pass

def adjust(change=None, target=None):
    with locked():
        current, maximum=read()
        percent=100*current/maximum
        percent=max(5,min(100, percent+change if change is not None else target))
        value=max(1,round(percent*maximum/100))
        if value!=current: ddc('setvcp','10',value)
    refresh_bar()

def status():
    try:
        with locked(): current, maximum=read()
        percent=round(100*current/maximum)
        icon='󰃞' if percent<35 else '󰃟' if percent<70 else '󰃠'
        return {'text':icon, 'class':'normal',
                'tooltip':f'显示器亮度 {percent}% · ASUS VG27AQ3A\n滚轮调节 ±5% · 点击打开滑块\nDDC/CI 硬件亮度'}
    except (RuntimeError,OSError,subprocess.TimeoutExpired):
        return {'text':'󰃠', 'class':'unavailable', 'tooltip':'显示器亮度暂不可用 · 请确认显示器已开启 DDC/CI'}

def panel():
    import gi
    gi.require_version('Gtk','3.0')
    gi.require_version('GtkLayerShell','0.1')
    gi.require_version('GLibUnix','2.0')
    from gi.repository import Gtk,Gdk,GLib,GLibUnix,GtkLayerShell
    lock=open(RUNTIME/f'waybar-brightness-panel-{os.getuid()}.lock','a+')
    try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        lock.seek(0)
        try: os.kill(int(lock.read()),signal.SIGUSR1)
        except (ValueError,ProcessLookupError): pass
        return
    lock.seek(0);lock.truncate();lock.write(str(os.getpid()));lock.flush()
    with locked(): current,maximum=read()
    window=Gtk.Window(title='显示器亮度')
    window.set_name('brightness-popup')
    window.set_app_paintable(True)
    visual=window.get_screen().get_rgba_visual()
    if visual: window.set_visual(visual)
    window.set_default_size(360,160)
    window.set_resizable(False)
    GtkLayerShell.init_for_window(window)
    GtkLayerShell.set_namespace(window,'notification-center')
    GtkLayerShell.set_layer(window,GtkLayerShell.Layer.OVERLAY)
    GtkLayerShell.set_keyboard_mode(window,GtkLayerShell.KeyboardMode.ON_DEMAND)
    for edge in (GtkLayerShell.Edge.TOP,GtkLayerShell.Edge.RIGHT): GtkLayerShell.set_anchor(window,edge,True)
    GtkLayerShell.set_margin(window,GtkLayerShell.Edge.TOP,12)
    GtkLayerShell.set_margin(window,GtkLayerShell.Edge.RIGHT,12)
    box=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=14)
    box.set_name('brightness-card');window.add(box)
    header=Gtk.Box(spacing=12)
    title=Gtk.Label(label='󰃠  显示器亮度',xalign=0);title.set_name('brightness-title')
    header.pack_start(title,True,True,0)
    close=Gtk.Button(label='×')
    header.pack_end(close,False,False,0);box.pack_start(header,False,False,0)
    hint=Gtk.Label(label='ASUS VG27AQ3A · 硬件亮度',xalign=0);hint.set_name('brightness-hint')
    box.pack_start(hint,False,False,0)
    scale=Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL,5,100,1)
    scale.set_value(round(100*current/maximum));scale.set_digits(0)
    scale.set_value_pos(Gtk.PositionType.RIGHT)
    box.pack_start(scale,False,False,0)
    timer=[None];pending=[None];worker=[None]
    def drain():
        if worker[0] is not None and worker[0].poll() is None: return True
        if worker[0] is not None and worker[0].returncode:
            hint.set_text('调节失败 · 请确认显示器 DDC/CI 已开启')
        worker[0]=None
        if pending[0] is not None:
            target=pending[0];pending[0]=None
            worker[0]=subprocess.Popen(['/usr/bin/python3',SELF,'--set',str(target)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            return True
        timer[0]=None
        return False
    def changed(widget):
        pending[0]=round(widget.get_value())
        if timer[0] is None: timer[0]=GLib.timeout_add(200,drain)
    scale.connect('value-changed',changed)
    # Flush the last slider position even if the panel closes immediately.
    def finish(*_):
        if pending[0] is not None:
            subprocess.Popen(['/usr/bin/python3',SELF,'--set',str(pending[0])],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        Gtk.main_quit()
    close.connect('clicked',finish)
    window.connect('destroy',finish)
    window.connect('key-press-event',lambda _,event: (finish(),True)[1] if event.keyval==Gdk.KEY_Escape else False)
    GLibUnix.signal_add(GLib.PRIORITY_DEFAULT,signal.SIGUSR1,lambda: (finish(),False)[1])
    css=Gtk.CssProvider()
    css.load_from_path(str(Path(SELF).with_name('brightness.css')))
    Gtk.StyleContext.add_provider_for_screen(window.get_screen(),css,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
    window.show_all();window.present();Gtk.main()

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--change',type=int)
    parser.add_argument('--set',type=int)
    parser.add_argument('--panel',action='store_true')
    args=parser.parse_args()
    try:
        if args.change is not None: adjust(change=args.change)
        elif args.set is not None: adjust(target=args.set)
        elif args.panel: panel()
        else: print(json.dumps(status(),ensure_ascii=False))
    except (RuntimeError,OSError,subprocess.TimeoutExpired) as error:
        print(str(error),file=sys.stderr);sys.exit(1)
