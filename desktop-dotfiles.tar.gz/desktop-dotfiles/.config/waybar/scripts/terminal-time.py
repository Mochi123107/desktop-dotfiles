#!/usr/bin/python3
"""Persist terminal foreground time; never record input or window titles."""
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import time
from datetime import date

ROOT = Path.home() / '.local/state/terminal-time'
TERMINALS = {'kitty', 'nvim-bluehour', 'btop-frost', 'alacritty', 'org.wezfurlong.wezterm',
             'foot', 'footclient', 'org.gnome.terminal', 'gnome-terminal-server',
             'konsole', 'com.mitchellh.ghostty', 'ghostty', 'tilix', 'xterm'}

def duration(seconds):
    minutes = int(seconds) // 60
    return f'{minutes // 60}h {minutes % 60:02d}m' if minutes >= 60 else f'{minutes}m'

def focused_terminal():
    try:
        r = subprocess.run(['hyprctl', '-j', 'activewindow'], capture_output=True,
                           text=True, timeout=1.5)
        return r.returncode == 0 and json.loads(r.stdout).get('class', '').lower() in TERMINALS
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return False

def main():
    ROOT.mkdir(parents=True, exist_ok=True)
    lock = (ROOT / 'tracker.lock').open('w')
    for attempt in range(30):
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if attempt == 29:
                return
            time.sleep(0.1)
    path = ROOT / 'usage.json'
    today = date.today().isoformat()
    state = {'total_seconds': 0.0, 'today_seconds': 0.0, 'date': today}
    if path.exists():
        try:
            saved = json.loads(path.read_text())
            state.update({k: max(0.0, float(saved[k])) for k in ('total_seconds', 'today_seconds')})
            state['date'] = saved.get('date', today)
        except (OSError, ValueError, KeyError, TypeError):
            # Preserve unreadable state instead of silently overwriting it.
            raise SystemExit('Cannot read terminal usage state')
    def save():
        temp = path.with_suffix('.tmp')
        temp.write_text(json.dumps(state, ensure_ascii=False) + '\n')
        temp.chmod(0o600)
        os.replace(temp, path)
    def stop(*_):
        save()
        raise SystemExit(0)
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    previous = time.monotonic()
    previous_active = False
    last_save = previous
    last_output = None
    save()
    try:
        while True:
            active = focused_terminal()
            now = time.monotonic()
            elapsed = now - previous
            current_day = date.today().isoformat()
            crossed_day = state['date'] != current_day
            if crossed_day:
                state['date'] = current_day
                state['today_seconds'] = 0.0
            # Conservative at focus changes; never add a long disconnected gap.
            if previous_active and active and elapsed <= 6:
                state['total_seconds'] += elapsed
                if not crossed_day:
                    state['today_seconds'] += elapsed
            previous, previous_active = now, active
            if now - last_save >= 15 or crossed_day:
                save()
                last_save = now
            output = json.dumps({
                'text': '  ' + duration(state['total_seconds']),
                'tooltip': '终端累计使用  ' + duration(state['total_seconds']) +
                           '\n今日使用  ' + duration(state['today_seconds']) +
                           '\n仅累计终端在前台的时间 · 从启用时开始记录',
                'class': 'active' if active else 'idle',
                'alt': 'terminal-time'}, ensure_ascii=False)
            if output != last_output:
                print(output, flush=True)
                last_output = output
            time.sleep(2)
    finally:
        save()

if __name__ == '__main__':
    main()
