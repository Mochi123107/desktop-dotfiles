#!/usr/bin/env python3
"""Follow the active output monitor and stream its CAVA spectrum to Waybar."""
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import tempfile
import time

GLYPHS = '▁▂▃▄▅▆▇█'

def stop(*_):
    raise SystemExit(0)

def render(values, active):
    return json.dumps({'text': ''.join(GLYPHS[min(7, max(0, v))] for v in values) if active else '',
                       'class': 'playing' if active else 'silent',
                       'tooltip': '实时音频频谱 · 低频 → 高频\n点击打开声音设置'}, ensure_ascii=False)

def active_monitor():
    result = subprocess.run(['pactl', '--format=json', 'list', 'sinks'],
                            capture_output=True, text=True, timeout=2)
    if result.returncode:
        raise RuntimeError(result.stderr.strip() or 'Cannot query audio outputs')
    sinks = json.loads(result.stdout)
    running = [sink for sink in sinks if sink.get('state', '').upper() == 'RUNNING']
    # Prefer Bluetooth if multiple devices are active.
    running.sort(key=lambda sink: not sink['name'].startswith('bluez'))
    if running:
        return running[0]['name'] + '.monitor'
    result = subprocess.run(['pactl', 'get-default-sink'], capture_output=True, text=True, timeout=2)
    return result.stdout.strip() + '.monitor' if result.returncode == 0 else 'auto'

def main():
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    template = (Path(__file__).resolve().parents[1] / 'spectrum.conf').read_text()
    process = None
    previous = None
    source = None
    last_audio = 0.0
    next_check = 0.0
    buffer = b''
    selector = selectors.DefaultSelector()
    print(render([], False), flush=True)
    with tempfile.TemporaryDirectory(prefix='waybar-spectrum-') as directory:
        config = Path(directory) / 'config'
        try:
            while True:
                now = time.monotonic()
                if now >= next_check:
                    selected = active_monitor()
                    next_check = now + 2
                    if selected != source or process is None or process.poll() is not None:
                        if process is not None:
                            selector.unregister(process.stdout)
                            if process.poll() is None:
                                process.terminate()
                                try:
                                    process.wait(timeout=1)
                                except subprocess.TimeoutExpired:
                                    process.kill()
                                    process.wait()
                            process.stdout.close()
                        source = selected
                        config.write_text(template.replace('source = auto', 'source = ' + source))
                        process = subprocess.Popen(['cava', '-p', str(config)], stdout=subprocess.PIPE)
                        selector.register(process.stdout, selectors.EVENT_READ)
                        buffer = b''
                for key, _ in selector.select(timeout=0.2):
                    chunk = os.read(key.fileobj.fileno(), 8192)
                    if not chunk:
                        time.sleep(0.1)
                        continue
                    buffer += chunk
                    while b'\n' in buffer:
                        line, buffer = buffer.split(b'\n', 1)
                        try:
                            values = [int(v) for v in line.strip().split(b';') if v]
                        except ValueError:
                            continue
                        if len(values) != 48:
                            continue
                        if any(values):
                            last_audio = time.monotonic()
                        frame = render(values, time.monotonic() - last_audio < 2)
                        if frame != previous:
                            print(frame, flush=True)
                            previous = frame
        finally:
            selector.close()
            if process is not None and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()

if __name__ == '__main__':
    main()
