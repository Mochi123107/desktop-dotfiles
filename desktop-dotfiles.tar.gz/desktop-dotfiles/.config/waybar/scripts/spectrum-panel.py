#!/usr/bin/python3
"""Draw an actual rounded-bar spectrum in a centered Wayland layer surface."""
import ctypes
import json
import math
from pathlib import Path
import signal
import subprocess
import sys
import gi

gi.require_version('Gtk', '3.0')
gi.require_version('GtkLayerShell', '0.1')
from gi.repository import Gtk, GtkLayerShell, GLib, Gdk

# Exit with Waybar, including when the custom-module shell is replaced.
ctypes.CDLL(None).prctl(1, signal.SIGTERM)
WIDTH, HEIGHT, COUNT = 480, 56, 48
window = Gtk.Window()
window.set_app_paintable(True)
visual = window.get_screen().get_rgba_visual()
if visual:
    window.set_visual(visual)
window.set_default_size(WIDTH, HEIGHT)
window.set_resizable(False)
GtkLayerShell.init_for_window(window)
GtkLayerShell.set_namespace(window, 'music-spectrum')
GtkLayerShell.set_layer(window, GtkLayerShell.Layer.TOP)
# Share Waybar's top row instead of being placed beneath its exclusive zone.
GtkLayerShell.set_exclusive_zone(window, -1)
GtkLayerShell.set_anchor(window, GtkLayerShell.Edge.TOP, True)
GtkLayerShell.set_margin(window, GtkLayerShell.Edge.TOP, 9)
GtkLayerShell.set_keyboard_mode(window, GtkLayerShell.KeyboardMode.NONE)
canvas = Gtk.DrawingArea()
canvas.set_size_request(WIDTH, HEIGHT)
window.add(canvas)
levels = [0.0] * COUNT
targets = [0.0] * COUNT
visible = False

def rounded(context, x, y, width, height, radius):
    context.new_sub_path()
    for cx, cy, start in ((x+width-radius, y+radius, -math.pi/2),
                          (x+width-radius, y+height-radius, 0),
                          (x+radius, y+height-radius, math.pi/2),
                          (x+radius, y+radius, math.pi)):
        context.arc(cx, cy, radius, start, start+math.pi/2)
    context.close_path()

def draw(widget, cr):
    import cairo
    cr.set_operator(cairo.OPERATOR_SOURCE)
    cr.set_source_rgba(0, 0, 0, 0)
    cr.paint()
    cr.set_operator(cairo.OPERATOR_OVER)
    # Match the status capsule's translucent glass and 56px top row.
    rounded(cr, 0.5, 0.5, WIDTH - 1, HEIGHT - 1, 16)
    glass = cairo.LinearGradient(0, 0, WIDTH, HEIGHT)
    glass.add_color_stop_rgba(0, 42/255, 63/255, 106/255, 0.26)
    glass.add_color_stop_rgba(1, 22/255, 35/255, 65/255, 0.18)
    cr.set_source(glass)
    cr.fill_preserve()
    cr.set_source_rgba(183/255, 214/255, 1, 0.24)
    cr.set_line_width(1)
    cr.stroke()
    # Fixed gaps and rounded ends, vertically centered like the reference.
    step = 9
    bar_width = 5
    start = (WIDTH - ((COUNT-1)*step + bar_width)) / 2
    for i, level in enumerate(levels):
        height = 8 + level * 28
        rounded(cr, start+i*step, (HEIGHT-height)/2, bar_width, height, 2.5)
        cr.set_source_rgba(0.32 + level*0.12, 0.50 + level*0.13, 0.74 + level*0.12, 0.95)
        cr.fill()
    return False

canvas.connect('draw', draw)
backend = subprocess.Popen([sys.executable, '-u', str(Path(__file__).with_name('spectrum.py'))],
                           stdout=subprocess.PIPE, text=True, bufsize=1)

def receive(stream, condition):
    global visible, targets
    if condition & (GLib.IO_HUP | GLib.IO_ERR):
        Gtk.main_quit()
        return False
    line = stream.readline()
    if not line:
        Gtk.main_quit()
        return False
    try:
        frame = json.loads(line)
        text = frame.get('text', '')
        glyphs = '▁▂▃▄▅▆▇█'
        if text:
            targets = [glyphs.index(char)/7 for char in text][:COUNT]
            targets += [0.0] * (COUNT-len(targets))
            if not visible:
                window.show_all()
                visible = True
        elif visible:
            window.hide()
            visible = False
    except (ValueError, TypeError):
        pass
    return True

def animate():
    for i in range(COUNT):
        levels[i] += (targets[i]-levels[i])*0.4
    if visible:
        canvas.queue_draw()
    return True

def shutdown(*args):
    Gtk.main_quit()
    return False

GLib.io_add_watch(backend.stdout, GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR, receive)
GLib.timeout_add(33, animate)
GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGTERM, shutdown)
GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGINT, shutdown)
# The Waybar custom module is just the lifetime owner; the panel draws itself.
print(json.dumps({'text': ''}), flush=True)
try:
    Gtk.main()
finally:
    backend.terminate()
    try:
        backend.wait(timeout=3)
    except subprocess.TimeoutExpired:
        backend.kill()
        backend.wait()
