#!/usr/bin/python3
"""Super+C closes the application grid first, otherwise the active window."""
from pathlib import Path
import os
import signal
import subprocess

launcher = b'/home/USER/.config/app-grid/launcher.py'
closed = False
for process in Path('/proc').iterdir():
    if not process.name.isdecimal():
        continue
    try:
        if process.stat().st_uid != os.getuid():
            continue
        args = (process / 'cmdline').read_bytes().split(b'\0')
        if len(args) > 1 and args[0] == b'/usr/bin/python3' and args[1] == launcher:
            os.kill(int(process.name), signal.SIGTERM)
            closed = True
    except (OSError, ProcessLookupError):
        continue
if not closed:
    subprocess.run(['hyprctl', 'dispatch', 'hl.dsp.window.close()'], check=False)
