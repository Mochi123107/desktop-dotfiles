#!/usr/bin/python3
"""A searchable, translucent application grid for the desktop."""
import fcntl
import os
from pathlib import Path
import shlex
import subprocess
import gi

gi.require_version('Gtk', '3.0')
gi.require_version('GtkLayerShell', '0.1')
from gi.repository import Gtk, Gdk, Gio, GLib, GtkLayerShell, Pango

lock = open(Path(os.environ.get('XDG_RUNTIME_DIR', '/tmp')) / 'mochita-app-grid.lock', 'w')
try:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
except BlockingIOError:
    raise SystemExit(0)

window = Gtk.Window(title='应用中心')
window.set_app_paintable(True)
visual = window.get_screen().get_rgba_visual()
if visual:
    window.set_visual(visual)
window.set_default_size(1140, 760)
window.set_resizable(False)
GtkLayerShell.init_for_window(window)
GtkLayerShell.set_namespace(window, 'frost-launcher')
GtkLayerShell.set_layer(window, GtkLayerShell.Layer.OVERLAY)
GtkLayerShell.set_keyboard_mode(window, GtkLayerShell.KeyboardMode.EXCLUSIVE)
window.set_name('app-grid')
outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
outer.set_name('app-panel')
outer.set_border_width(0)
window.add(outer)
search = Gtk.SearchEntry(placeholder_text='搜索应用…')
search.set_name('search')
outer.pack_start(search, False, False, 0)
scroll = Gtk.ScrolledWindow()
scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
outer.pack_start(scroll, True, True, 0)
flow = Gtk.FlowBox()
flow.set_selection_mode(Gtk.SelectionMode.NONE)
flow.set_min_children_per_line(6)
flow.set_max_children_per_line(6)
flow.set_homogeneous(True)
flow.set_column_spacing(12)
flow.set_row_spacing(12)
flow.set_valign(Gtk.Align.START)
scroll.add(flow)
status = Gtk.Label()
status.set_name('hint')
outer.pack_start(status, False, False, 0)
apps = sorted((a for a in Gio.AppInfo.get_all() if a.should_show()), key=lambda a: a.get_display_name().casefold())

def launch(button, app):
    try:
        if isinstance(app, Gio.DesktopAppInfo) and app.get_boolean('Terminal'):
            tokens = shlex.split(app.get_string('Exec'))
            argv = []
            for token in tokens:
                if token in ('%f', '%F', '%u', '%U', '%i', '%d', '%D', '%n', '%N', '%v', '%m'):
                    continue
                argv.append(token.replace('%c', app.get_display_name()).replace('%k', app.get_filename()).replace('%%', '%'))
            subprocess.Popen(['/usr/bin/kitty', '--'] + argv, start_new_session=True)
        else:
            context = Gdk.Display.get_default().get_app_launch_context()
            app.launch([], context)
        Gtk.main_quit()
    except Exception as error:
        status.set_text('启动失败：' + str(error))

for app in apps:
    button = Gtk.Button()
    button.set_name('app-tile')
    button.set_tooltip_text(app.get_display_name())
    content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
    content.set_halign(Gtk.Align.CENTER)
    icon = Gtk.Image.new_from_gicon(app.get_icon() or Gio.ThemedIcon.new('application-x-executable'), Gtk.IconSize.DIALOG)
    icon.set_pixel_size(64)
    content.pack_start(icon, False, False, 0)
    label = Gtk.Label(label=app.get_display_name())
    label.set_max_width_chars(14)
    label.set_ellipsize(Pango.EllipsizeMode.END)
    label.set_justify(Gtk.Justification.CENTER)
    content.pack_start(label, False, False, 0)
    button.add(content)
    button.connect('clicked', launch, app)
    flow.add(button)
    child = button.get_parent()
    child.search_text = ' '.join((app.get_display_name(), app.get_description() or '', app.get_executable() or '')).casefold()

flow.set_filter_func(lambda child: all(word in child.search_text for word in search.get_text().casefold().split()))
search.connect('search-changed', lambda _: flow.invalidate_filter())
def activate_first(_):
    for child in flow.get_children():
        if child.get_child_visible():
            child.get_child().clicked()
            break
search.connect('activate', activate_first)
def keypress(_, event):
    if (event.state & Gdk.ModifierType.SUPER_MASK) and event.keyval in (Gdk.KEY_c, Gdk.KEY_C):
        Gtk.main_quit()
        return True
    return False
window.connect('key-press-event', keypress)
window.connect('destroy', Gtk.main_quit)
provider = Gtk.CssProvider()
provider.load_from_path(str(Path(__file__).with_name('style.css')))
Gtk.StyleContext.add_provider_for_screen(window.get_screen(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
window.show_all()
search.grab_focus()
Gtk.main()
